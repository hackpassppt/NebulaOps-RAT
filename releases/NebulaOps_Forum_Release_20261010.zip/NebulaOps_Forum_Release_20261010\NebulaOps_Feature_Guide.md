# NebulaOps
## Next-Generation Red Team Command Platform

> Operate like a product. Strike like a platform. Present like a war room.

NebulaOps is a demo-grade offensive operations console. It unifies delivery, beaconing, mission orchestration, in-memory tradecraft, lateral movement, battlefield visualization, and audit reporting inside one light, modern WinForms control center.

---

## Product Character

- **Product-like**: light UI, card metrics, clean hierarchy
- **Platform-like**: full narrative from build to report
- **War-room-like**: War Room / Attack Graph / Mission Timeline are projection-ready

---

## Feature Map

### 1. Control Center Dashboard
Live fleet, listener state, event stream, and module entry points.

### 2. War Room
Fullscreen command board with high-contrast cards and live counters.

### 3. Campaign Wizard
One-click delivery ZIP: agent, shellcode, mining profile, lateral playbook, notes, and evasion score metadata.

### 4. Builder + Evasion Pipeline
Post-build noise / obfuscation / anti-sandbox / metadata randomization with a showable build score.

### 5. Shellcode Factory
BIN / HEX / C / PS1 / PY / CS exports. Prefers donut, with automatic fallback.

### 6. Injector
LocalThread / RemoteThread, optional XOR payloads, multi-host dispatch.

### 7. Memory Tradecraft Workbench
AssemblyLoad, EarlyBirdAPC, hollowing-style chains, local/remote threads, live OPSEC score and advice.

### 8. Mission Scheduler + Timeline
Ordered playbooks with live result timeline — SOAR-like offensive workflow control.

### 9. Attack Graph
Hosts / credentials / shares / DCs as a click-to-action battle map.

### 10. Geo Fleet Map
Geographic fleet situational awareness for demos and operations.

### 11. Beacon Builder
Multi-channel profiles (TLS / HTTPS-WS / Cloudflare / DoH / Telegram) with agent generation workflows.

### 12. Lateral Lab
CIDR expansion, SMB/RDP/WinRM probing, DiscoverOnly / SprayLight / ShareDrop / PsRemote style playbooks, Armed gate for offensive actions.

### 13. Mining Console
URL fetch, persistence, watchdog, fleet start/stop, telemetry-friendly status.

### 14. HVNC
Hidden desktop sessions, frame polling, quality and path controls.

### 15. Module Store + RBAC + Audit + Report
Extension narrative, role skeleton, audit trail, one-click HTML report.

---

## Signature Loops

1. **60-second demo loop**: War Room → Attack Graph → Mission Timeline → Beacon → HTML Report
2. **Delivery loop**: Builder score → Campaign ZIP → Shellcode → Injector/Memory
3. **Fleet loop**: Geo Map → Lateral → Mission → HVNC/Memory → Audit

---

## Quick Start

1. Keep all files in the same folder after extraction
2. Run `NebulaOps.exe`
3. Requires .NET Framework 4.5.2+
4. Complete Certificate Wizard on first launch if prompted

---

## One-Liner

**NebulaOps is the red-team command platform that makes operations feel like a product launch.**

—
NebulaOps / Nebula Labs
